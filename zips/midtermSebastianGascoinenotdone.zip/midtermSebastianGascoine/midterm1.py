# File Name:     midterm1.py
# Programmer:    Sebastian Gascoine
# Date:          Oct. 12, 2022
#
# Problem Statement: Write a program that finds the mean, 
# median, and standard deviation of a list of numbers which you read from a file.  
# 1 number per line and should support both positive and negative number. 


import math
from re import T


def main():
    #open up the input file
    input = open('C:/Users/MCCLAB560WD12/Desktop/midtermSebastianGascoine/input.txt')
    text = mean(input)
    print("mean is: " + str(text))
    
    input.close()

def mean(input):
    means = 0
    #add all the values together
    for i in input:
        means+= int(i) 
    # amount of lines in file over added values get mean
    lines_in_file = open('C:/Users/MCCLAB560WD12/Desktop/midtermSebastianGascoine/input.txt').readlines()
    number_of_lines = len(lines_in_file)   
    means = means/number_of_lines

    return means

def median(input):
    #mean = mean(input)
    medians = 0
    for i in input:
        pass
    return medians

def StdDev(input): #doesnt work StdDev doesnt call for loop

    deviation = 0
    #retDev = 'The Standard Deviation is:'
    differs = []
    total = 0
    means = mean(input)

    for i in input:
        retDev = '555'
        
    
    #deviation = deviation/(means-1)
    #retDev += str(math.sqrt(deviation))

    
    return retDev


main()