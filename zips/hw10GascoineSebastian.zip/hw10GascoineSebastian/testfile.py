# def
def main():
    a = True
    if(a):
        return
    elif(a):
main()
