# File Name:     hw6project1.py
# Programmer:    Sebastian Gascoine
# Date:          Sep. 28, 2022
#
# Problem Statement: Write a program to print the lyrics for ten verses of "The Ants Go Marching." This function should be called ten times.

def main():
    # I want to make a for loop 10 times for each verse and add it to lyrics
    lyrics = ''
    for i in range(2):
        numants , actionlit = eval(input("List how many ants there are and the action of them and the action of the little one Ex:(one, sucks his thumb)"))
        lyrics += functionAnts(numants,actionlit)
        pass
    
    # since I am returning values from the function i am declaring from the function to call in print statement
    print(lyrics)


def functionAnts(num,lit):
    lyric = ''
    for i in range(2):
        lyric += march(num)
        pass

    lyric += 'The little one stops to' + lit
    lyric += 'And they all go marching down to the ground'
    lyric += 'To get out of the rain, BOOM! BOOM! BOOM!'
 
    return lyric
def march(num):
    return 'The ants go marching'+ num + 'by' + num + ', hurrah, hurra'
main()