# convert.py
#     A program to convert Celsius temps to Fahrenheit
# by: Susan Computewell

def main():
    print("This is a program to convert Fahrenheit temperature to Celsius")
    fahrenheit = eval(input("What is the Fahrenheit temperature? "))
    celsius = 5(fahrenheit – 32)/9
    print("The temperature is", celsius, "degrees Celsius.")

main()
